#ifndef __MAIN_H
#define __MAIN_H

#include "stm32f10x.h"
#include "step_motor.h"
#include "Delay.h"
#include "Key.h"
#include "Timer.h"
#include "LED.h"


uint8_t KeyNum = 0;
uint8_t Run_Flag = 0;





#endif
