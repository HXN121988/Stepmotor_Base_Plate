#include "stm32f10x.h"
#include "systick.h"
#include "step_motor.h"

int main(void)
{
    // 外设初始化
    SysTick_Init();
    StepMotor_Init();

    // 上电使能驱动器
    StepMotor_Enable();

    while (1)
    {
        /********** 示例1：基础正反转 **********/
        // StepMotor_RunRPM(60, DIR_CW, 1);   // 正转1圈，60转/分
        // Delay_ms(500);
        // StepMotor_RunRPM(60, DIR_CCW, 1);  // 反转1圈，60转/分
        // Delay_ms(500);

        /********** 示例2：调速扫描测试 **********/
        // for(uint16_t r = 20; r <= 150; r+=10)
        // {
        //     StepMotor_RunRPM(r, DIR_CW, 0.5);
        // }
        // Delay_ms(1000);

        /********** 示例3：梯形加减速长距离运行 **********/
        // 总步数10000，启动转速20rpm，最高120rpm，加减速各2000步
        StepMotor_MoveWithAccel(10000, DIR_CW, 20, 120, 2000);
        Delay_ms(1000);
        StepMotor_MoveWithAccel(10000, DIR_CCW, 20, 120, 2000);
        Delay_ms(1000);
    }
}



