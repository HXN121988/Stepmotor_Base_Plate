#include "main.h"

int main(void)
{
	
	Key_Init();
	
	LED_Init();
	Motor_Init();
	
	Timer_Init();
	
	Motor_Enable();
	Motor_MoveSteps(6400);
	while(1)
	{
		
		
	}
}

void TIM1_UP_IRQHandler()
{
  
  if(TIM_GetITStatus(TIM1, TIM_IT_Update) == SET)
  {
	  TIM_ClearITPendingBit(TIM1, TIM_IT_Update);
	  Key_Tick();
		
		
	}
}

