#include "systick.h"

static uint32_t g_fac_us;      // 微秒延时因子

/**
 * @brief  初始化SysTick，时钟源为HCLK/8
 */
void SysTick_Init(void)
{
    SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);
    g_fac_us = SystemCoreClock / 8000000;
}

/**
 * @brief  微秒级延时
 * @param  us: 延时微秒数
 */
void Delay_us(uint32_t us)
{
    uint32_t temp;
    SysTick->LOAD = us * g_fac_us;
    SysTick->VAL  = 0x00;
    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;
    do
    {
        temp = SysTick->CTRL;
    } while ((temp & 0x01) && !(temp & (1 << 16)));
    SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;
    SysTick->VAL  = 0x00;
}

/**
 * @brief  毫秒级延时
 * @param  ms: 延时毫秒数
 */
void Delay_ms(uint32_t ms)
{
    while (ms--)
    {
        Delay_us(1000);
    }
}



