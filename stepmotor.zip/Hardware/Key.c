#include "stm32f10x.h"                  // Device header
#include "Delay.h"

uint8_t Key_Num;

void Key_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_10|GPIO_Pin_11 ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
}

uint8_t Key_GetNum(void)
{
	uint8_t Temp;
	if (Key_Num)
	{
		Temp = Key_Num;
		Key_Num = 0;
		return Temp;
	}
	return 0;
}

// 返回bit0:PB0, bit1:PB1, bit2:PB10, bit3:PB11，bit置1代表按键按下
uint8_t Key_GetState(void)
{
	uint8_t ret = 0;
	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) ret |= (1 << 0);
	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_1) == 0) ret |= (1 << 1);
	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_10)== 0) ret |= (1 << 2);
	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_11)== 0) ret |= (1 << 3);
	return ret;
}



void Key_Tick(void)
{
	static uint8_t Count;
	static uint8_t CurrState, PrevState;
	Count ++;
	if (Count >= 20)
	{
		Count = 0;
		PrevState = CurrState;
		CurrState = Key_GetState();

		if( ( (PrevState & (1<<0)) == 0 ) && ( (CurrState & (1<<0)) !=0 ) )
		{
			Key_Num = 1;
		}
		
		if( ( (PrevState & (1<<1)) == 0 ) && ( (CurrState & (1<<1)) !=0 ) )
		{
			Key_Num = 2;
		}
		
		if( ( (PrevState & (1<<2)) == 0 ) && ( (CurrState & (1<<2)) !=0 ) )
		{
			Key_Num = 3;
		}
		
		if( ( (PrevState & (1<<3)) == 0 ) && ( (CurrState & (1<<3)) !=0 ) )
		{
			Key_Num = 4;
		}
	}
}

