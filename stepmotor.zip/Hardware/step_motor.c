#include "step_motor.h"
#include "systick.h"

/**
 * @brief  步进电机GPIO初始化
 */
void StepMotor_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

    GPIO_InitStructure.GPIO_Pin = STEP_PIN | DIR_PIN | EN_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(STEP_PORT, &GPIO_InitStructure);

    GPIO_ResetBits(STEP_PORT, STEP_PIN);  // STEP默认低电平
    GPIO_SetBits(EN_PORT, EN_PIN);        // EN默认高电平=驱动器失能
}

/**
 * @brief  使能驱动器输出
 */
void StepMotor_Enable(void)
{
    GPIO_ResetBits(EN_PORT, EN_PIN);
    Delay_ms(10);  // 等待驱动器上电稳定
}

/**
 * @brief  关闭驱动器输出
 */
void StepMotor_Disable(void)
{
    GPIO_SetBits(EN_PORT, EN_PIN);
}

/**
 * @brief  设置旋转方向
 * @param  dir: DIR_CW / DIR_CCW
 */
void StepMotor_SetDir(uint8_t dir)
{
    if (dir == DIR_CW)
        GPIO_SetBits(DIR_PORT, DIR_PIN);
    else
        GPIO_ResetBits(DIR_PORT, DIR_PIN);
    Delay_us(5);  // 方向建立时间
}

/**
 * @brief  输出单个步进脉冲
 */
static void StepMotor_SinglePulse(void)
{
    GPIO_SetBits(STEP_PORT, STEP_PIN);
    Delay_us(PULSE_HIGH_US);
    GPIO_ResetBits(STEP_PORT, STEP_PIN);
}

/**
 * @brief  定步数恒速运行
 * @param  steps: 总脉冲数
 * @param  dir: 旋转方向
 * @param  pulse_interval_us: 脉冲间隔（微秒），值越小速度越快
 */
void StepMotor_Steps(uint32_t steps, uint8_t dir, uint32_t pulse_interval_us)
{
    StepMotor_SetDir(dir);
    while (steps--)
    {
        StepMotor_SinglePulse();
        Delay_us(pulse_interval_us - PULSE_HIGH_US);
    }
}

/**
 * @brief  按指定转速运行指定圈数
 * @param  rpm: 转速（转/分钟）
 * @param  dir: 旋转方向
 * @param  rounds: 运行圈数
 */
void StepMotor_RunRPM(uint16_t rpm, uint8_t dir, uint32_t rounds)
{
    uint32_t interval_us;
    uint32_t total_steps;

    if (rpm == 0 || rounds == 0) return;

    // 单脉冲间隔 = 60*10^6 us / (转速 * 每圈脉冲数)
    interval_us = 60000000UL / (rpm * PULSE_PER_ROUND);
    total_steps = rounds * PULSE_PER_ROUND;

    StepMotor_Steps(total_steps, dir, interval_us);
}

/**
 * @brief  梯形加减速运行（长距离防丢步）
 * @param  total_steps: 总步数
 * @param  dir: 方向
 * @param  start_rpm: 启动转速
 * @param  max_rpm: 最高转速
 * @param  acc_steps: 加减速段步数（加速段=减速段）
 */
void StepMotor_MoveWithAccel(uint32_t total_steps, uint8_t dir,
                             uint16_t start_rpm, uint16_t max_rpm, uint16_t acc_steps)
{
    uint32_t i;
    uint32_t interval_us;
    int16_t rpm_step;

    // 总步数不足时自动缩减加减速段
    if (total_steps < 2 * acc_steps)
        acc_steps = total_steps / 2;

    StepMotor_SetDir(dir);

    // 加速段
    rpm_step = (max_rpm - start_rpm) / acc_steps;
    for (i = 0; i < acc_steps; i++)
    {
        interval_us = 60000000UL / ((start_rpm + i * rpm_step) * PULSE_PER_ROUND);
        StepMotor_SinglePulse();
        Delay_us(interval_us - PULSE_HIGH_US);
    }

    // 匀速段
    interval_us = 60000000UL / (max_rpm * PULSE_PER_ROUND);
    for (i = 0; i < total_steps - 2 * acc_steps; i++)
    {
        StepMotor_SinglePulse();
        Delay_us(interval_us - PULSE_HIGH_US);
    }

    // 减速段
    for (i = 0; i < acc_steps; i++)
    {
        interval_us = 60000000UL / ((max_rpm - i * rpm_step) * PULSE_PER_ROUND);
        StepMotor_SinglePulse();
        Delay_us(interval_us - PULSE_HIGH_US);
    }
}


