#include "step_motor.h"

/************************ 内部变量 ************************/
static volatile uint8_t  run_flag = 0;     // 运行标志
static volatile int32_t  cur_steps = 0;    // 当前累计步数
static volatile int32_t  target_steps = 0; // 目标步数（定步长模式）
static volatile uint8_t  step_level = 0;   // STEP引脚电平状态

/************************ 底层GPIO初始化 ************************/
static void Motor_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

    GPIO_InitStructure.GPIO_Pin   = STEP_PIN | DIR_PIN | EN_PIN;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(MOTOR_PORT, &GPIO_InitStructure);

    // 初始状态：EN高电平（脱机）、STEP低、DIR正转
    GPIO_SetBits(MOTOR_PORT, EN_PIN);
    GPIO_ResetBits(MOTOR_PORT, STEP_PIN);
    GPIO_SetBits(MOTOR_PORT, DIR_PIN);
}

/************************ TIM2定时器初始化 ************************/
static void Motor_TIM_Init(void)
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

    // 默认1000Hz脉冲 → 定时器中断2000Hz（翻转两次=一个脉冲）
    // 计数频率1MHz（72MHz/72）
    TIM_TimeBaseStructure.TIM_Prescaler = 72 - 1;
    TIM_TimeBaseStructure.TIM_Period    = 500 - 1;  // 1M/500 = 2000Hz中断 → 1000Hz脉冲
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

    TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    TIM_Cmd(TIM2, ENABLE);
}

/************************ 公开函数：初始化 ************************/
void Motor_Init(void)
{
    Motor_GPIO_Init();
    Motor_TIM_Init();
    run_flag = 0;
    cur_steps = 0;
    target_steps = 0;
}

/************************ 公开函数：使能/失能 ************************/
void Motor_Enable(void)
{
    GPIO_ResetBits(MOTOR_PORT, EN_PIN); // EN低电平使能TMC2209
}

void Motor_Disable(void)
{
    GPIO_SetBits(MOTOR_PORT, EN_PIN);  // EN高电平脱机
    run_flag = 0;
    GPIO_ResetBits(MOTOR_PORT, STEP_PIN);
}

/************************ 公开函数：设置方向 ************************/
void Motor_SetDir(uint8_t dir)
{
    if(dir == DIR_CW)
        GPIO_SetBits(MOTOR_PORT, DIR_PIN);
    else
        GPIO_ResetBits(MOTOR_PORT, DIR_PIN);
}

/************************ 公开函数：设置脉冲频率 ************************/
void Motor_SetFreq(uint16_t freq)
{
    uint32_t arr;
    if(freq == 0) freq = 1;
    // 计数频率1MHz，中断频率=2*脉冲频率
    arr = 1000000 / (2 * freq) - 1;
    if(arr < 1) arr = 1;

    TIM_SetAutoreload(TIM2, arr);
    TIM_SetCounter(TIM2, 0);
}

/************************ 公开函数：设置转速RPM ************************/
void Motor_SetRPM(float rpm)
{
    uint16_t freq;
    // 频率 = 转速*每圈步数 / 60
    freq = (uint16_t)(rpm * STEP_PER_ROUND / 60.0f);
    if(freq > 20000) freq = 20000; // 上限保护
    Motor_SetFreq(freq);
}

/************************ 公开函数：持续转动 ************************/
void Motor_Start(void)
{
    target_steps = 0;  // 清除定步长模式
    run_flag = 1;
}

/************************ 公开函数：立即停止 ************************/
void Motor_Stop(void)
{
    run_flag = 0;
    GPIO_ResetBits(MOTOR_PORT, STEP_PIN);
    step_level = 0;
}

/************************ 公开函数：指定步数运动 ************************/
void Motor_MoveSteps(int32_t steps)
{
    if(steps > 0)
    {
        Motor_SetDir(DIR_CW);
        target_steps = steps;
    }
    else
    {
        Motor_SetDir(DIR_CCW);
        target_steps = -steps;
    }
    cur_steps = 0;
    run_flag = 1;
}

/************************ 公开函数：状态查询 ************************/
uint8_t Motor_IsRunning(void)
{
    return run_flag;
}

int32_t Motor_GetCurSteps(void)
{
    return cur_steps;
}

/************************ TIM2中断服务函数 ************************/
void TIM2_IRQHandler(void)
{
    if(TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
    {
        TIM_ClearITPendingBit(TIM2, TIM_IT_Update);

        if(run_flag)
        {
            step_level = !step_level;
            if(step_level)
            {
                GPIO_SetBits(MOTOR_PORT, STEP_PIN);
                // 上升沿走一步，步数+1
                cur_steps++;

                // 定步长模式：到达目标停止
                if(target_steps != 0 && cur_steps >= target_steps)
                {
                    Motor_Stop();
                }
            }
            else
            {
                GPIO_ResetBits(MOTOR_PORT, STEP_PIN);
            }
        }
    }
}

