#ifndef __STEP_MOTOR_H
#define __STEP_MOTOR_H

#include "stm32f10x.h"

/************************ 硬件配置宏 ************************/
#define STEP_PORT       GPIOA
#define STEP_PIN        GPIO_Pin_0
#define DIR_PORT        GPIOA
#define DIR_PIN         GPIO_Pin_1
#define EN_PORT         GPIOA
#define EN_PIN          GPIO_Pin_2

/************************ 参数配置宏 ************************/
#define DIR_CW          1       // 正转
#define DIR_CCW         0       // 反转
#define PULSE_PER_ROUND 3200    // 每圈脉冲数（16细分，200步电机）
#define PULSE_HIGH_US   5       // 脉冲高电平最小宽度

/************************ 函数声明 ************************/
void StepMotor_Init(void);
void StepMotor_Enable(void);
void StepMotor_Disable(void);
void StepMotor_SetDir(uint8_t dir);

// 基础功能：定步数恒速运行
void StepMotor_Steps(uint32_t steps, uint8_t dir, uint32_t pulse_interval_us);

// 进阶功能：按转速运行指定圈数
void StepMotor_RunRPM(uint16_t rpm, uint8_t dir, uint32_t rounds);

// 高级功能：梯形加减速运行（防丢步）
void StepMotor_MoveWithAccel(uint32_t total_steps, uint8_t dir, 
                             uint16_t start_rpm, uint16_t max_rpm, uint16_t acc_steps);

#endif



