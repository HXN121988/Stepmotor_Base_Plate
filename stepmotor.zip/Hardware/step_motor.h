#ifndef __STEP_MOTOR_H
#define __STEP_MOTOR_H
#include "stm32f10x.h"

/************************ 硬件引脚定义 ************************/
#define STEP_PIN        GPIO_Pin_0
#define DIR_PIN         GPIO_Pin_1
#define EN_PIN          GPIO_Pin_2
#define MOTOR_PORT      GPIOA

/************************ 电机参数配置 ************************/
#define FULL_STEP_PER_ROUND   200     // 整步：200步/圈（1.8°电机）
#define MICRO_STEP            64       // TMC2209细分：悬空默认1/8细分
#define STEP_PER_ROUND        (FULL_STEP_PER_ROUND * MICRO_STEP)  // 实际每圈步数

/************************ 方向定义 ************************/
#define DIR_CW      1   // 顺时针
#define DIR_CCW     0   // 逆时针

/************************ 函数声明 ************************/
// 初始化
void Motor_Init(void);

// 基础控制
void Motor_Enable(void);       // 使能驱动（电机锁止）
void Motor_Disable(void);      // 失能驱动（电机脱机，可手转）
void Motor_SetDir(uint8_t dir);// 设置转动方向

// 速度控制（单位：脉冲频率Hz，数值越大转速越快）
void Motor_SetFreq(uint16_t freq);
// 速度控制（单位：转速RPM，转/分钟）
void Motor_SetRPM(float rpm);

// 运动控制
void Motor_Start(void);        // 持续转动
void Motor_Stop(void);         // 立即停止
void Motor_MoveSteps(int32_t steps);  // 指定步数运动（正数正转，负数反转）

// 状态查询
uint8_t Motor_IsRunning(void); // 查询是否正在运行
int32_t Motor_GetCurSteps(void); // 获取当前累计步数

#endif
